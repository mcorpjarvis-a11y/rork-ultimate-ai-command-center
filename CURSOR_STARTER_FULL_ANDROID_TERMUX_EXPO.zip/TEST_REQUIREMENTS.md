
# TEST REQUIREMENTS
- TokenVault CRUD + index
- AuthManager start/refresh/revoke + events
- MasterProfile save/get/clear + connectedProviders
- ConnectionsHub connect/disconnect behavior
- ProviderHelpers request correctness (URLs, headers, scope parsing, expires_at)
