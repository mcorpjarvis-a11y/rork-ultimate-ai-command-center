
# CONNECTIONS HUB SPEC
- Tiles: Connected / Not Connected / Needs Re-Auth
- Actions: Connect, Disconnect, Local Token (for HA/Hue)
- Events: update on AuthManager 'connected'/'disconnected'/'token_refreshed'
