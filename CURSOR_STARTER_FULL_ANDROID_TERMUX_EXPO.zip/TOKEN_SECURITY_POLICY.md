
# TOKEN SECURITY POLICY
- No secrets in repo
- No token logs
- SecureKeyStorage backend required
- Access tokens short-lived; refresh handled automatically
