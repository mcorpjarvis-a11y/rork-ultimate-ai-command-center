
# DEVICE FLOW (TERMUX)
- Show user_code + verification_uri
- Poll token endpoint
- Save tokens to TokenVault
- Providers: GitHub device, Reddit installed app; Google partial; fallback to external consent + code paste
