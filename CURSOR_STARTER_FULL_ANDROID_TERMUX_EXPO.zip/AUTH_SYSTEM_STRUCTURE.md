
# AUTH SYSTEM STRUCTURE
- Android/Termux/Expo only.
- AuthManager, TokenVault, MasterProfile, providerHelpers, ConnectionsHub, SignInScreen.
- Services fetch tokens only via AuthManager.
