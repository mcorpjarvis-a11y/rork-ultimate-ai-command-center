
# README for Cursor
- Read CURSOR_PR_INSTRUCTIONS.txt and follow stepwise plan.
- After each major step, run tests and do a sanity run.
- Do not add iOS. Respect Apple-block script.
- Use PROVIDERS_MATRIX.csv for endpoints and scopes.
